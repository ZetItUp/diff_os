#pragma once

#include <syscall.h>

int exec_dex(const char *path, int argc, char **argv);
