#pragma once

int isspace(int c);
