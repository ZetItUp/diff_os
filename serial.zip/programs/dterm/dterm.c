#include <system/command_registry.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>
#include <dirent.h>
#include <syscall.h>

/* ===== Shell metadata ===== */
static const char *g_shell_name   = "Different Terminal";
static const unsigned g_ver_major = 1;
static const unsigned g_ver_minor = 0;

/* ===== Writable CWD buffer (inte literal) ===== */
static char g_cwd[256] = "/";

/* --------------------------------------------------------------------------
   SÄKER PATH-NORMALISERING
   -------------------------------------------------------------------------- */

/* --- Prototyp MÅSTE komma före parse_into för att undvika implicit extern --- */
static void split_into_parts(const char *p, char parts[][64], int *count);

static void parts_push(char parts[][64], int *count, const char *s)
{
    if (!s || !*s) return;
    if (*count >= 64) return;
    strncpy(parts[*count], s, 63);
    parts[*count][63] = '\0';
    (*count)++;
}

static void parts_pop(int *count)
{
    if (*count > 0) (*count)--;
}

static inline void parse_into(const char *p, char parts[][64], int *count)
{
    /* wrapper för kompatibilitet med tidigare callsite-namn */
    split_into_parts(p, parts, count);
}

static void split_into_parts(const char *p, char parts[][64], int *count)
{
    if (!p) return;

    while (*p == '/') p++;

    while (*p) {
        const char *start = p;
        while (*p && *p != '/') p++;
        size_t len = (size_t)(p - start);

        if (len) {
            char tmp[64];
            if (len >= sizeof(tmp)) len = sizeof(tmp) - 1;
            memcpy(tmp, start, len);
            tmp[len] = '\0';

            if (strcmp(tmp, ".") == 0) {
                /* ignore */
            } else if (strcmp(tmp, "..") == 0) {
                parts_pop(count);
            } else {
                parts_push(parts, count, tmp);
            }
        }
        while (*p == '/') p++;
    }
}

/* Resolve input mot base (om relativt). Skriver absolut, normaliserad path i `out`.
   Returnerar 0 vid OK, -1 vid overflow/ogiltigt. */
static int normalize_path(const char *base, const char *input, char *out, size_t outsz)
{
    if (!out || outsz == 0) return -1;

    char parts[64][64];
    int  count = 0;

    const bool absolute = (input && input[0] == '/');

    if (!absolute) {
        parse_into((base && base[0]) ? base : "/", parts, &count);
    } else {
        count = 0;
    }

    parse_into((input && input[0]) ? input : "/", parts, &count);

    /* root? */
    if (count == 0) {
        if (outsz < 2) return -1;
        out[0] = '/';
        out[1] = '\0';
        return 0;
    }

    size_t off = 0;

    for (int i = 0; i < count; i++) {
        const char *seg = parts[i];
        size_t seglen = strlen(seg);

        /* Måste få plats med '/' + segment och lämna plats för slutlig NUL */
        if (off + 1 + seglen >= outsz) {
            if (outsz) out[0] = '\0';   /* skriv INGET partiellt */
            return -1;                  /* rapportera FEL */
        }

        out[off++] = '/';
        memcpy(out + off, seg, seglen);
        off += seglen;
    }

    if (off >= outsz) return -1;
    out[off] = '\0';
    return 0;
}

/* -------------------------------------------------------------------------- */
/* Builtins: cd/help/echo/ver/exit (command_registry lämnas orörd)            */
/* -------------------------------------------------------------------------- */

static int bi_help(int argc, char **argv)
{
    (void)argc; (void)argv;
    puts("  cd      \tChange current directory");
    puts("  help    \tList built-in commands");
    puts("  echo    \tPrint its arguments");
    puts("  ver     \tShow shell version");
    puts("  exit    \tExit the shell");
    return 0;
}

static int bi_echo(int argc, char **argv)
{
    for (int i = 1; i < argc; i++) {
        if (i > 1) putchar(' ');
        printf("%s", argv[i]);
    }
    putchar('\n');
    return 0;
}

static int bi_ver(int argc, char **argv)
{
    (void)argc; (void)argv;
    printf("%s (Version %u.%u)\n", g_shell_name, g_ver_major, g_ver_minor);
    return 0;
}

static int bi_exit(int argc, char **argv)
{
    (void)argc; (void)argv;
    exit(0);
    return 0;
}

/* cd: normalisera säkert, validera med opendir innan CWD uppdateras */
static int bi_cd(int argc, char **argv)
{
    const char *arg = (argc < 2 || !argv[1] || !argv[1][0]) ? "/" : argv[1];

    char norm[256];
    if (normalize_path(g_cwd, arg, norm, sizeof(norm)) != 0) {
        puts("cd: path too long");
        return -1;
    }

    DIR *d = opendir(norm);
    if (!d) {
        printf("cd: no such directory: %s\n", arg);
        return -1;
    }
    closedir(d);

    strncpy(g_cwd, norm, sizeof(g_cwd) - 1);
    g_cwd[sizeof(g_cwd) - 1] = '\0';
    return 0;
}

/* -------------------------------------------------------------------------- */
/* Kommandokörning: först registry → exec_dex(path, argc, argv), annars builtins */
/* -------------------------------------------------------------------------- */

static int tokenize(char *line, char **argv, int maxv)
{
    int argc = 0;
    char *s = line;

    size_t n = strlen(s);
    if (n && (s[n-1] == '\n' || s[n-1] == '\r')) s[--n] = 0;

    while (*s && argc < maxv) {
        while (*s == ' ' || *s == '\t') s++;
        if (!*s) break;
        argv[argc++] = s;
        while (*s && *s != ' ' && *s != '\t' && *s != '\r' && *s != '\n') s++;
        if (!*s) break;
        *s++ = 0;
    }
    return argc;
}

static int run_builtin(int argc, char **argv)
{
    if (argc == 0) return 0;

    if (strcmp(argv[0], "cd")   == 0) return bi_cd(argc, argv);
    if (strcmp(argv[0], "help") == 0) return bi_help(argc, argv);
    if (strcmp(argv[0], "echo") == 0) return bi_echo(argc, argv);
    if (strcmp(argv[0], "ver")  == 0) return bi_ver(argc, argv);
    if (strcmp(argv[0], "exit") == 0) return bi_exit(argc, argv);

    return 1; /* inte builtin */
}

static int run_external(int argc, char **argv)
{
    if (argc == 0) return 0;

    /* Command registry: lookup → exec_dex */
    const char *path = cmdreg_lookup(argv[0]);
    if (!path) {
        printf("Unknown command: %s\n", argv[0]);
        return -1;
    }
    return exec_dex(path, argc, argv);
}

/* -------------------------------------------------------------------------- */
/* Main-loop (oförändrad struktur)                                            */
/* -------------------------------------------------------------------------- */

int main(void)
{
    if (!cmdreg_init("/system/commands.map")) {
        puts("[CRITICAL ERROR] Unable to initialize command registry!");
    }

    printf("\n%s (Version %u.%u)\n\n", g_shell_name, g_ver_major, g_ver_minor);

    char *line = NULL;
    size_t cap = 0;

    for (;;) {
        printf("%s> ", g_cwd);

        int x, y;
        console_getxy(&x, &y);
        console_floor_set(x, y);

        ssize_t n = getline(&line, &cap);
        console_floor_clear();

        if (n <= 0) continue;

        char *argv[16];
        int argc = tokenize(line, argv, 16);
        if (argc == 0) continue;

        /* Builtins först; annars externa via registry */
        int rc = run_builtin(argc, argv);
        if (rc == 1) {
            run_external(argc, argv);
        }
    }
}

