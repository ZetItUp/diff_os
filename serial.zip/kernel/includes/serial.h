#pragma once

void serial_init(void);
void serial_putc(char c);
