#pragma once

#include "stdint.h"

#define NULL ((void*)0)

typedef unsigned int size_t;

